Song metadata templates live here for reference only.

Runtime files must be placed next to each song chart:

  data/[song-name]/song_meta.json

For example:

  data/test/song_meta.json

The New Freeplay loader and Chart Editor both use that location.
If you keep reusable examples in this folder, copy them into the song folder before shipping your mod.
