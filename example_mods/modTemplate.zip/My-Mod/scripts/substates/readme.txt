Add substate-specific scripts here!

Hardcoded substates can load companion scripts named after the substate class:

  scripts/substates/PauseSubState.hx
  scripts/substates/PauseSubState.lua

ScriptableSubstate uses scripts/substates/[SubstateName].hx.
LuaSubstate uses scripts/substates/[SubstateName].lua.

Optional presets:

  scripts/substates/_substatePreset.hx
  scripts/substates/_preset.lua

Keep these scripts small and state-safe. If a script should run everywhere, put it in scripts/ instead.
