Add state-specific scripts here!

Create a folder for each state (e.g., "MainMenuState", "PlayState", "StoryMenuState").
Scripts inside each state folder will run only when that state is active.

Supported formats: .lua, .hx, .hscript, .hsc, .hxs
Variables like "this", "game", "FlxG" are pre-injected.

Example structure:
  scripts/states/MainMenuState.hx
  scripts/states/MainMenuState.lua
  scripts/states/_statePreset.hx
  scripts/states/_preset.lua

Hardcoded states can load companion scripts named after the state class.
ScriptableState and CustomState also use scripts/states/[StateName].hx.
LuaState uses scripts/states/[StateName].lua.
