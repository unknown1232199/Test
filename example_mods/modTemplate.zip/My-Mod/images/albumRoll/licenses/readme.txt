Optional New Freeplay license badges go here.

The engine looks for PNG badges by normalized license id, for example:

  images/albumRoll/licenses/creative-commons.png
  images/albumRoll/licenses/cc-by.png
  images/albumRoll/licenses/public-domain.png

song_meta.json accepts "licenses" as an array or a comma-separated string.
If nothing is set, the engine uses "no-licenses".
