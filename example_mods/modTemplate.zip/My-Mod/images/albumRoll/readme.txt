New Freeplay album assets go here.

Default lookups:

  images/albumRoll/[song-name].png
  images/albumRoll/cards/[song-name].png

If song_meta.json has "cover" or "card", the engine normalizes short names into this folder.
For example, "cover": "my-album" loads images/albumRoll/my-album.png.

Use square PNG files for covers. The engine rounds the corners at runtime.
